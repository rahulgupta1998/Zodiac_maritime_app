UI component functions can be moved here as the application grows.
