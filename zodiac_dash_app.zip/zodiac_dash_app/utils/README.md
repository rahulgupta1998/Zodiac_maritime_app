Utility helpers can be placed here.
