# Windows setup guide – Zodiac Maritime Dash application

## A. Install software

### 1. Python
Use Python 3.11 for this project. Databricks Apps currently requires Python 3.11 or above for Python apps, while the managed Apps environment uses Python 3.11 for pip-based apps.

Check after installation:

```powershell
python --version
```

Expected:

```text
Python 3.11.x
```

If `python` is not recognized, restart VS Code/PowerShell after installing Python and verify the Python entry is available on PATH.

### 2. Visual Studio Code
Install the Windows User Setup. It is the easiest option for a normal developer machine.

Recommended VS Code extensions:

- Python (Microsoft)
- Pylance (Microsoft)
- YAML (Red Hat)
- GitLens (optional)

### 3. Git
Install Git for Windows. Check:

```powershell
git --version
```

### 4. Databricks CLI
You only need this when you start the deployment phase. The current Databricks Apps documentation requires Databricks CLI 0.229.0 or later and recommends OAuth user-to-machine authentication.

Check:

```powershell
databricks -v
```

If it is not installed yet, do not block local development on it; finish the local app first.

---

## B. Create the project

Open PowerShell:

```powershell
cd C:\Users\YOUR_NAME\Documents
mkdir zodiac-maritime-dashboard
cd zodiac-maritime-dashboard
code .
```

Copy the supplied project files into this folder, or extract the project zip here.

---

## C. Create the virtual environment

From the project root:

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
```

You should now see something similar to:

```text
(.venv) PS C:\Users\...\zodiac-maritime-dashboard>
```

If PowerShell prevents activation, run:

```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

Then activate again:

```powershell
.venv\Scripts\Activate.ps1
```

Alternative without PowerShell activation:

```powershell
.venv\Scripts\python.exe -m pip install -r requirements.txt
.venv\Scripts\python.exe app.py
```

---

## D. Select the virtual environment in VS Code

Press:

```text
Ctrl + Shift + P
```

Choose:

```text
Python: Select Interpreter
```

Select:

```text
.venv\Scripts\python.exe
```

Then open a new VS Code terminal and verify:

```powershell
python --version
where python
```

`where python` should point to the `.venv\Scripts` folder first.

---

## E. Install the Python packages

Upgrade pip first:

```powershell
python -m pip install --upgrade pip
```

Install the project requirements:

```powershell
pip install -r requirements.txt
```

Check the important packages:

```powershell
pip show dash
pip show plotly
pip show pandas
pip show dash-ag-grid
pip show dash-bootstrap-components
```

If everything works, freeze the environment so the exact versions used locally can be captured:

```powershell
pip freeze > requirements.lock.txt
```

For the assessment repository, keep the intentional `requirements.txt`; `requirements.lock.txt` is an additional reproducibility aid.

---

## F. Add the assessment CSV

The app expects exactly:

```text
data\vessel_kpi_reports.csv
```

Do not rename it unless you also change `services/data_service.py`.

The first run creates:

```text
data\zodiac.db
```

That is the local SQLite persistence layer for the assessment.

---

## G. First run

Run:

```powershell
python app.py
```

You should see a local Dash URL, normally:

```text
http://127.0.0.1:8050/
```

Open the URL in Chrome/Edge.

Stop the app with:

```text
Ctrl + C
```

---

## H. What to check on the first successful run

1. Page opens without a Python traceback.
2. Vessel dropdown contains the vessels from the CSV.
3. Date range is populated.
4. Power chart renders points.
5. Speed chart renders points.
6. Selecting points changes the table.
7. Box-select works.
8. Lasso-select works.
9. Power_% / Speed_% cells are editable.
10. Negative deviations are highlighted.
11. Save Changes writes to SQLite.
12. The audit_log table receives changed-field records.

---

## I. Useful commands

Check installed Python packages:

```powershell
pip list
```

Check Dash:

```powershell
pip show dash
```

Check syntax:

```powershell
python -m py_compile app.py services\data_service.py database\db.py services\validation.py
```

Start without debug reloads:

```powershell
$env:PORT=8050
python app.py
```

---

## J. Common Windows problems

### Problem: `python` is not recognized

Try:

```powershell
py --version
```

If `py` works but `python` does not, use `py -3.11` to create the environment:

```powershell
py -3.11 -m venv .venv
```

### Problem: `Activate.ps1 cannot be loaded`

Run:

```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

Then activate again.

### Problem: `ModuleNotFoundError: dash`

The virtual environment is probably not active. Verify:

```powershell
where python
pip show dash
```

If necessary:

```powershell
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

### Problem: CSV not found

Confirm the exact location:

```text
zodiac-maritime-dashboard
└── data
    └── vessel_kpi_reports.csv
```

### Problem: expected-column error

The app validates the assessment schema. Compare the CSV headers with the required fields in `services/data_service.py`.

### Problem: database has old test values

Stop the app and delete:

```text
data\zodiac.db
```

Then start the app again. It will rebuild the SQLite file from the CSV.

---

## K. Important deployment rule

Develop locally first. Databricks Apps supports local development followed by deployment to the workspace. Keep `app.py`, `requirements.txt`, and `app.yaml` at the root of the app project.

The assessment only requires the Databricks `app.yaml` deployment shape; it does not require the SQLite implementation to become a production Databricks persistence solution. For production, the database layer should be replaced by Databricks SQL/Delta access.
