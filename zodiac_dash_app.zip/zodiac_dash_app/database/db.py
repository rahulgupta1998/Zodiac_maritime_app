from pathlib import Path
import sqlite3
from datetime import datetime, timezone
import pandas as pd

from services.data_service import load_csv, source_to_db_df, db_to_source_df

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DB_PATH = PROJECT_ROOT / "data" / "zodiac.db"

CREATE_REPORTS_SQL = """
CREATE TABLE IF NOT EXISTS reports (
    row_id INTEGER PRIMARY KEY,
    IMO TEXT,
    Vessel_Name TEXT,
    Report_ID TEXT,
    To_Timestamp TEXT,
    KPI TEXT,
    Voyage_Type TEXT,
    Report_Duration REAL,
    SP_BSL_Start REAL,
    SP_BSL_End REAL,
    SP_BSL_Reports REAL,
    ME_Running_Hours REAL,
    Dual_Fuel_Mode_str TEXT,
    PWR_BSL_SAM REAL,
    Power_ME REAL,
    Power_pct REAL,
    Power_Deviation REAL,
    Power_Filter_Flag TEXT,
    SPD_BSL_SAM REAL,
    SPD_BSL_OOS REAL,
    Speed_pct REAL,
    Speed_Deviation REAL,
    Speed_Filter TEXT
)
"""

CREATE_AUDIT_SQL = """
CREATE TABLE IF NOT EXISTS audit_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    Report_ID TEXT NOT NULL,
    field TEXT NOT NULL,
    old_value TEXT,
    new_value TEXT,
    user TEXT NOT NULL,
    timestamp TEXT NOT NULL
)
"""


EDITABLE_MAP = {
    "Power_%": "Power_pct",
    "Speed_%": "Speed_pct",
}


def get_connection():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    return sqlite3.connect(DB_PATH)


def initialize_database():
    with get_connection() as conn:
        conn.execute(CREATE_REPORTS_SQL)
        conn.execute(CREATE_AUDIT_SQL)
        count = conn.execute("SELECT COUNT(*) FROM reports").fetchone()[0]
        if count == 0:
            df = load_csv()
            db_df = source_to_db_df(df)
            columns = list(db_df.columns)
            columns = [c for c in columns if c != "row_id"]
            placeholders = ",".join(["?"] * (len(columns) + 1))
            quoted = ",".join([f'"{c}"' for c in columns])
            sql = f'INSERT INTO reports (row_id,{quoted}) VALUES ({placeholders})'
            for _, row in db_df.iterrows():
                values = [int(row["row_id"]) ] + [None if pd.isna(row[c]) else row[c] for c in columns]
                conn.execute(sql, values)
            conn.commit()


def load_reports() -> pd.DataFrame:
    with get_connection() as conn:
        df = pd.read_sql_query("SELECT * FROM reports ORDER BY row_id", conn)
    return db_to_source_df(df)


def _value_equal(a, b):
    if pd.isna(a) and pd.isna(b):
        return True
    if a is None and b is None:
        return True
    try:
        return float(a) == float(b)
    except (TypeError, ValueError):
        return str(a) == str(b)


def save_report_changes(rows, user: str) -> int:
    changed_count = 0
    now = datetime.now(timezone.utc).isoformat()
    with get_connection() as conn:
        for row in rows:
            row_id = int(row["row_id"])
            current = conn.execute(
                "SELECT Report_ID, Power_pct, Speed_pct FROM reports WHERE row_id = ?",
                (row_id,),
            ).fetchone()
            if not current:
                raise ValueError(f"Unknown row_id: {row_id}")

            report_id, old_power, old_speed = current
            for source_field, db_field, old_value in [
                ("Power_%", "Power_pct", old_power),
                ("Speed_%", "Speed_pct", old_speed),
            ]:
                if source_field not in row:
                    continue
                new_value = row[source_field]
                if isinstance(new_value, str) and not new_value.strip():
                    new_value = None
                if new_value is not None:
                    new_value = float(new_value)

                if _value_equal(old_value, new_value):
                    continue

                conn.execute(
                    f'UPDATE reports SET "{db_field}" = ? WHERE row_id = ?',
                    (new_value, row_id),
                )
                conn.execute(
                    "INSERT INTO audit_log (Report_ID, field, old_value, new_value, user, timestamp) VALUES (?, ?, ?, ?, ?, ?)",
                    (report_id, source_field, None if old_value is None else str(old_value), None if new_value is None else str(new_value), user, now),
                )
                changed_count += 1
        conn.commit()
    return changed_count
