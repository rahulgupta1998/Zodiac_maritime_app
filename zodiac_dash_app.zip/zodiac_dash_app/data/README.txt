Put the assessment dataset here with this exact filename:

vessel_kpi_reports.csv

The app will initialize data/zodiac.db from the CSV on the first run.
Do not submit generated SQLite files unless your assessment instructions explicitly require one.
