import math

# The assessment asks for a "sane range" but does not specify exact limits.
# These are deliberately documented assumptions for the take-home solution.
MIN_PERCENT = 0.0
MAX_PERCENT = 200.0


def _number(value, field, row_label):
    if value is None or value == "":
        return None, f"{row_label}: {field} cannot be blank."
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None, f"{row_label}: {field} must be numeric."
    if not math.isfinite(number):
        return None, f"{row_label}: {field} must be a finite number."
    if not (MIN_PERCENT <= number <= MAX_PERCENT):
        return None, f"{row_label}: {field} must be between {MIN_PERCENT:g} and {MAX_PERCENT:g}."
    return number, None


def validate_changes(rows):
    errors = []
    for row in rows:
        label = f"Report {row.get('Report_ID', row.get('row_id', '?'))}"
        if row.get("KPI") == "Power":
            _, err = _number(row.get("Power_%"), "Power_%", label)
            if err:
                errors.append(err)
        if row.get("KPI") == "Speed":
            _, err = _number(row.get("Speed_%"), "Speed_%", label)
            if err:
                errors.append(err)
    return errors
