from pathlib import Path
import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parents[1]
CSV_PATH = PROJECT_ROOT / "data" / "vessel_kpi_reports.csv"

FILTER_COLUMNS = ["Vessel_Name", "To_Timestamp", "KPI", "Voyage_Type"]
NUMERIC_COLUMNS = [
    "Report_Duration", "SP_BSL_Start", "SP_BSL_End", "SP_BSL_Reports",
    "ME_Running_Hours", "PWR_BSL_SAM", "Power_ME", "Power_%", "Power_Deviation",
    "SPD_BSL_SAM", "SPD_BSL_OOS", "Speed_%", "Speed_Deviation"
]

SOURCE_TO_DB = {
    "Power_%": "Power_pct",
    "Speed_%": "Speed_pct",
}
DB_TO_SOURCE = {v: k for k, v in SOURCE_TO_DB.items()}

EXPECTED_COLUMNS = [
    "IMO", "Vessel_Name", "Report_ID", "To_Timestamp", "KPI", "Voyage_Type",
    "Report_Duration", "SP_BSL_Start", "SP_BSL_End", "SP_BSL_Reports",
    "ME_Running_Hours", "Dual_Fuel_Mode_str", "PWR_BSL_SAM", "Power_ME", "Power_%",
    "Power_Deviation", "Power_Filter_Flag", "SPD_BSL_SAM", "SPD_BSL_OOS", "Speed_%",
    "Speed_Deviation", "Speed_Filter"
]


def load_csv() -> pd.DataFrame:
    if not CSV_PATH.exists():
        raise FileNotFoundError(
            f"Missing dataset: {CSV_PATH}. Place the supplied vessel_kpi_reports.csv file in the data folder."
        )
    df = pd.read_csv(CSV_PATH)
    missing = [c for c in EXPECTED_COLUMNS if c not in df.columns]
    if missing:
        raise ValueError(f"Dataset is missing expected columns: {missing}")

    df = df.copy()
    df["To_Timestamp"] = pd.to_datetime(df["To_Timestamp"], errors="coerce")
    for col in NUMERIC_COLUMNS:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    df["row_id"] = range(len(df))
    return df


def source_to_db_df(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out = out.rename(columns=SOURCE_TO_DB)
    out["To_Timestamp"] = out["To_Timestamp"].dt.strftime("%Y-%m-%d %H:%M:%S")
    return out


def db_to_source_df(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out = out.rename(columns=DB_TO_SOURCE)
    out["To_Timestamp"] = pd.to_datetime(out["To_Timestamp"], errors="coerce")
    for col in NUMERIC_COLUMNS:
        if col in out.columns:
            out[col] = pd.to_numeric(out[col], errors="coerce")
    return out
